import cv2
import time
from PIL import Image
from facenet import Facenet
capture = cv2.VideoCapture(0)
time.sleep(1)
tot = 0
model = Facenet()
def checkLiu(frame):
    prob = 100
    image = Image.open("img/test_{}.jpg".format(0))
    mimage = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    probability = model.detect_image(mimage, image)
    prob = min(prob, probability)
    if prob < 0.75:
        return True, prob
    return False, prob
def checkLian(frame):
    prob = 100
    image = Image.open("img/test_{}.jpg".format(1))
    mimage = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    probability = model.detect_image(mimage, image)
    prob = min(prob, probability)
    if prob < 0.75:
        return True, prob
    return False, prob
def checkLi1(frame):
    prob = 100
    image = Image.open("img/test_{}.jpg".format(2))
    mimage = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    probability = model.detect_image(mimage, image)
    prob = min(prob, probability)
    if prob < 0.75:
        return True, prob
    return False, prob
tot = 0
while True:
    ret, frame = capture.read()
    faceCascade = cv2.CascadeClassifier('haarcascade_frontalface_alt2.xml')
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = faceCascade.detectMultiScale(gray, 1.1, 4, minSize = (100, 100))
    ans0 = 0
    ans1 = 0
    ans2 = 0
    probability0 = 100
    probability1 = 100
    probability2 = 100
    tms = 0
    if len(faces) > 0:
        x, y, w, h = faces[0]
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        mframe = frame[y:y+h, x:x+w]
        ans0, probability0 = checkLiu(mframe)
        ans1, probability1 = checkLian(mframe)
        ans2, probability2 = checkLi1(mframe)
        tms = 1
    #prob = probability
    prob = min(probability0, probability1, probability2)
    #print(probability, probability2)
    font = cv2.FONT_HERSHEY_SIMPLEX
    text = "distance is" + str(prob)
    textt = ""
    warn = "No stranger detected"
    if ans0 == True:
        textt = "You are Liu Haoyu"
        tot = 0
    elif ans1 == True:
        textt = "You are Lian Hui"
        tot = 0
    elif ans2 == True:
        textt = "You are Li Yuheng"
        tot = 0
    else:
        textt = "You are not in the database"
        if tms == 1:
            tot += 3
            tot = min(180, tot)
        else:
            tot -= 1
            tot = max(0, tot)

    if tot >= 120:
        warn = "Danger!"
    cv2.putText(frame, text, (50, 50), font, 1, (255,0,0), 1)
    cv2.putText(frame, textt, (50, 100), font, 1, (255,0,0), 2)
    cv2.putText(frame, warn, (50, 250), font, 2, (0,0,255), 5)
    cv2.imshow('frame', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cv2.destroyAllWindows()